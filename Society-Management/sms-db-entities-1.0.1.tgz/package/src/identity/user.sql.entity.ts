import { RoleSqlEntity } from './role.sql.entity';
import { Entity, PrimaryGeneratedColumn, Column, ManyToOne, JoinColumn, CreateDateColumn, UpdateDateColumn } from 'typeorm';

@Entity({
  name: 'users',
  schema: 'identity',
})
export class UserSqlEntity {

  // id uuid NOT NULL DEFAULT gen_random_uuid()
  @PrimaryGeneratedColumn('uuid')
  id: string;

  // mobile varchar(20) NOT NULL UNIQUE
  @Column({ unique: true })
  mobile: string;

  // name varchar(100)
  @Column({ nullable: true })
  name?: string;

  // email varchar(150)
  @Column({ nullable: true })
  email?: string;

  // role_unq_id uuid  (NO FK in DB)
  @Column({ nullable: true })
  role_unq_id?: string;

  // Many-to-One relation (logical only, no DB FK)
  @ManyToOne(() => RoleSqlEntity, {
    createForeignKeyConstraints: false, // IMPORTANT
    nullable: true,
  })
  @JoinColumn({ name: 'role_unq_id' })
  role?: RoleSqlEntity;

  // status smallint DEFAULT 1
  @Column({ type: 'smallint', default: 1 })
  status: number;

  // refresh_token_hash text
  @Column({ nullable: true, type: 'text' })
  refresh_token_hash: string | null;

  // created_by varchar(100)
  @Column({ length: 100, nullable: true })
  created_by?: string;

  // created_at timestamp DEFAULT now()
  @CreateDateColumn({ type: 'timestamp' })
  created_at: Date;

  // updated_by varchar(100)
  @Column({ length: 100, nullable: true })
  updated_by?: string;

  // updated_at timestamp DEFAULT now()
  @UpdateDateColumn({ type: 'timestamp' })
  updated_at: Date;
  // }


}
