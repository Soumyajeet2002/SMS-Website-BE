import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
} from 'typeorm';

@Entity({
  name: 'city_master',
  schema: 'public',
})
export class CityMaster {
  @PrimaryGeneratedColumn('uuid', { name: 'city_id' })
  cityId: string;

  @Column({ name: 'city_code', type: 'varchar', length: 50 })
  cityCode: string;

  @Column({ name: 'city_name', type: 'varchar', length: 150 })
  cityName: string;

  @Column({ name: 'state_id', type: 'uuid', nullable: true })
  stateId: string;

  @Column({ name: 'display_order', type: 'int', default: 0 })
  displayOrder: number;

  @Column({ name: 'status', type: 'smallint', default: 1 })
  status: number;

  @Column({ name: 'metadata', type: 'jsonb', default: {} })
  metadata: Record<string, any>;

  @Column({ name: 'created_by', type: 'uuid', nullable: true })
  createdBy: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
    default: () => 'now()',
  })
  createdAt: Date;

  @Column({ name: 'updated_by', type: 'uuid', nullable: true })
  updatedBy: string;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
    nullable: true,
  })
  updatedAt: Date;
}
