// entities/services.entity.ts

import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
  Check,
} from 'typeorm';

/**
 * Status Convention
 * 0 = Inactive
 * 1 = Active
 * 2 = Deleted
 */
export enum ServiceStatus {
  INACTIVE = 0,
  ACTIVE = 1,
  DELETED = 2,
}

@Entity({
  name: 'services_master',
  schema: 'society_master',
})

@Check(`"status" IN (0,1,2)`)

// Index for filtering by status
@Index('idx_services_status', ['status'])

export class ServicesMasterEntity {

  /* Primary Key */
  @PrimaryGeneratedColumn('uuid', { name: 'service_id' })
  serviceId: string;

  /* Business Columns */

  @Column({ name: 'service_code', type: 'varchar', length: 50 })
  serviceCode: string;

  @Column({ name: 'service_name', type: 'varchar', length: 150 })
  serviceName: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ name: 'service_type', type: 'varchar', length: 30, nullable: true })
  serviceType?: string;

  @Column({
    name: 'is_mandatory',
    type: 'boolean',
    default: false,
  })
  isMandatory: boolean;

  @Column({ name: 'icon_url', type: 'text', nullable: true })
  iconUrl?: string;

  @Column({
    name: 'display_order',
    type: 'integer',
    default: 0,
  })
  displayOrder: number;

  /**
   * 0 = Inactive
   * 1 = Active
   * 2 = Deleted
   */
  @Column({
    type: 'smallint',
    default: ServiceStatus.ACTIVE,
    comment: '0=Inactive, 1=Active, 2=Deleted',
  })
  status: ServiceStatus;

  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, any>;

  /* Audit Columns */

  @Column({ name: 'created_by', type: 'uuid', nullable: true })
  createdBy?: string;

  @CreateDateColumn({
    name: 'created_at',
    type: 'timestamptz',
    default: () => 'NOW()',
  })
  createdAt: Date;

  @Column({ name: 'updated_by', type: 'uuid', nullable: true })
  updatedBy?: string;

  @UpdateDateColumn({
    name: 'updated_at',
    type: 'timestamptz',
    nullable: true,
  })
  updatedAt?: Date;
}