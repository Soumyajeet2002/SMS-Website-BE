// entities/amenity.entity.ts

import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  CreateDateColumn,
  UpdateDateColumn,
  Index,
} from 'typeorm';

/**
 * Status Convention
 * 0 = Inactive
 * 1 = Active
 * 2 = Deleted (Soft Delete)
 */
export enum AmenityStatus {
  INACTIVE = 0,
  ACTIVE = 1,
  DELETED = 2,
}

@Entity({ name: 'amenities_master', schema: 'society_master' })

// Partial Unique Index (Only Active Records)
@Index('uq_amenity_code_active', ['amenityCode'], {
  unique: true,
  where: `"status" = 1`,
})

// Optional index for filtering
@Index('idx_amenities_status', ['status'])

export class AmenityEntity {

  /* Primary Key */
  @PrimaryGeneratedColumn('uuid', { name: 'amenity_id' })
  amenityId: string;

  /* Business Fields */
  @Column({ name: 'amenity_code', type: 'varchar', length: 50 })
  amenityCode: string;

  @Column({ name: 'amenity_name', type: 'varchar', length: 150 })
  amenityName: string;

  @Column({ type: 'text', nullable: true })
  description?: string;

  @Column({ name: 'icon_url', type: 'text', nullable: true })
  iconUrl?: string;

  @Column({ name: 'is_chargeable', type: 'boolean', default: false })
  isChargeable: boolean;

  @Column({ name: 'display_order', type: 'int', default: 0 })
  displayOrder: number;

  /**
   * Status Field
   * Replaces isActive + isDeleted
   */
  @Column({
    type: 'smallint',
    default: AmenityStatus.ACTIVE,
    comment: '0=Inactive, 1=Active, 2=Deleted',
  })
  status: AmenityStatus;

  @Column({ type: 'jsonb', nullable: true })
  metadata?: Record<string, any>;

  /* Audit Fields */
  @Column({ name: 'created_by', type: 'uuid', nullable: true })
  createdBy?: string;

  @CreateDateColumn({ name: 'created_at', type: 'timestamptz' })
  createdAt: Date;

  @Column({ name: 'updated_by', type: 'uuid', nullable: true })
  updatedBy?: string;

  @UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' })
  updatedAt?: Date;
}