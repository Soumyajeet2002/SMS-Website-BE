import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Index,
    CreateDateColumn,
    UpdateDateColumn,
} from 'typeorm';

@Entity({
    name: 'gencode_master',
    schema: 'society_master',
})
// @Index('idx_gencode_master_group_code', ['groupCode'])
// @Index('idx_gencode_master_gen_code', ['genCode'])
// @Index('uq_gencode_master_group_gen', ['groupCode', 'genCode'], {
//     unique: true,
// })
export class GencodeMasterEntity {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ type: 'varchar', length: 50 })
    group_code: string;

    @Column({ type: 'varchar', length: 50 })
    gen_code: string;

    @Column({ type: 'varchar', length: 150 })
    name: string;

    @Column({ type: 'integer', default: 0 })
    display_order: number;

    @Column({ type: 'smallint', default: 1 })
    status: number;

    @Column({ type: 'uuid', nullable: true })
    created_by?: string;

    @CreateDateColumn({ type: 'timestamptz', default: () => 'NOW()' })
    created_at: Date;

    @Column({ type: 'uuid', nullable: true })
    updated_by?: string;

    @UpdateDateColumn({ type: 'timestamptz', nullable: true })
    updated_at?: Date;
}
