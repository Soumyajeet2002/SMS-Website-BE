import { Entity, Column, PrimaryColumn, ManyToOne, JoinColumn } from 'typeorm';

@Entity({
    name: 'district_master',
    schema: 'public',
})
export class DistrictMasterSqlEntity {

    @PrimaryColumn({ type: 'int' })
    district_code: number;

    @Column({ type: 'varchar', length: 60 })
    district_name: string;

    @Column({ type: 'int' })
    state_code: number;

    @Column({ type: 'smallint' })
    status: number;

}
