// entities/society-level.entity.ts
import {
Entity,
Column,
PrimaryGeneratedColumn,
Index,
CreateDateColumn,
UpdateDateColumn,
} from 'typeorm';

@Entity({ name: 'society_level_master', schema: 'society_master' })
// @Index('uq_society_level_code_active', ['levelCode'], {
// unique: true,
// where: `"is_deleted" = false`,
// })
export class SocietyLevelEntity {
@PrimaryGeneratedColumn('uuid', { name: 'society_level_id' })
societyLevelId: string;

@Column({ name: 'level_code'  })
levelCode: string;

@Column({ name: 'level_name' })
levelName: string;

@Column({ type: 'text', nullable: true })
description?: string;

@Column({ type: 'jsonb',name:'rule_definition', nullable: true })
ruleDefinition?: Record<string, any>;

@Column({ name: 'display_order', type: 'int', default: 0 })
displayOrder: number;

@Column({ name: 'is_active', default: true })
isActive: boolean;

@Column({ name: 'is_deleted', default: false })
isDeleted: boolean;

@Column({ name: 'created_by', type: 'uuid', nullable: true })
createdBy?: string;

@CreateDateColumn({ name: 'created_at', type: 'timestamptz' })
createdAt: Date;

@Column({ name: 'updated_by', type: 'uuid', nullable: true })
updatedBy?: string;

@UpdateDateColumn({ name: 'updated_at', type: 'timestamptz' })
updatedAt?: Date;
}