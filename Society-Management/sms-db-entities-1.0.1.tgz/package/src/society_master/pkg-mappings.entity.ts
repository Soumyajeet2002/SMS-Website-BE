import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    CreateDateColumn,
    UpdateDateColumn,
    Index,
} from 'typeorm';

@Entity({
    schema: 'society_master',
    name: 'package_mappings',
})
@Index(
    'uq_package_mapping',
    ['package_id', 'map_type', 'map_ref_code'],
    { unique: true },
)
export class PackageMappingEntity {
    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column({ type: 'uuid' })
    package_id: string;

    @Column({ type: 'varchar', length: 50 })
    map_type: string; // AMT_TIER, SER_CATEGORY

    @Column({ type: 'varchar', length: 50 })
    map_ref_code: string;

    @Column({
        type: 'smallint',
        default: 1,
        comment: '0=Inactive, 1=Active, 2=Deleted',
    })
    status: number;

    @Column({ type: 'uuid' })
    created_by: string;

    @CreateDateColumn({
        type: 'timestamptz',
        default: () => 'NOW()',
    })
    created_at: Date;

    @Column({ type: 'uuid', nullable: true })
    updated_by?: string;

    @UpdateDateColumn({
        type: 'timestamptz',
        nullable: true,
    })
    updated_at?: Date;
}
