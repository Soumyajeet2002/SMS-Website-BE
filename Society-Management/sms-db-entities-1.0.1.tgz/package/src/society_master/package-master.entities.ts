import { Check, Column, Entity, PrimaryGeneratedColumn } from "typeorm";

@Entity({
    name: 'package_master',
    schema: 'society_master'
})
@Check(`"trial_days" >= 0`)
export class PackageMasterSql {

    @PrimaryGeneratedColumn('uuid')
    package_id: string;

    @Column({ length: 50, nullable: false, unique: true })
    package_code: string;

    @Column({ length: 150, nullable: false })
    package_name: string;

    @Column({
        type: 'varchar',
        length: 20,
        enum: ['MONTHLY', 'QUARTERLY', 'HALF_YEARLY', 'YEARLY', 'CUSTOM'],
    })
    billing_cycle: string;

    @Column({ type: 'int', nullable: true })
    duration_days: number;

    @Column({
        type: 'numeric',
        precision: 12,
        scale: 2,
        nullable: false,
    })
    price: number;

    @Column({ type: 'boolean', default: false })
    allows_trial: boolean

    @Column({ type: 'int', default: 0 })
    trial_days: number;

    @Column({
        type: "smallint",
        default: 1,
        enum: [0, 1, 2]
    })
    status: number;

    @Column({ type: 'uuid', nullable: true })
    created_by?: string;

    @Column({
        type: "timestamptz",
        default: () => 'NOW()',
    })
    created_at: Date;

    @Column({ type: 'uuid', nullable: true })
    updated_by?: string;

    @Column({ type: "timestamptz", nullable: true })
    updated_at?: Date;

}