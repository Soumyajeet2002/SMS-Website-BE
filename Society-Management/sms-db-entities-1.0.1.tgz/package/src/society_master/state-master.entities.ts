import { Entity, Column, PrimaryColumn } from 'typeorm';

@Entity({
  name: 'state_masters',
  schema: 'public',
})
export class StateMasterSqlEntity {
  @PrimaryColumn({ type: 'int' })
  state_code: number;

  @Column({ type: 'varchar', length: 60 })
  state_name: string;

  @Column({ type: 'smallint' })
  status: number;
}
